package de.mwvb.blockpuzzle.gamedefinition;

public interface ICrushed {

    void crushed(int areaSize);
}
