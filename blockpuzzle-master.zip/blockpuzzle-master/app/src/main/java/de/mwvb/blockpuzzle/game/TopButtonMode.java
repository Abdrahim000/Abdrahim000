package de.mwvb.blockpuzzle.game;

/**
 * Button above playing field
 */
public enum TopButtonMode {
    NEW_GAME,
    UNDO, // TODO bei Game over könnte man den Button ausblenden
    NO_BUTTON
}
