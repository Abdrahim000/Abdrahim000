package de.mwvb.blockpuzzle.global;

public enum GameType {

    NOT_SELECTED,
    OLD_GAME,
    STONE_WARS
}
