package de.mwvb.blockpuzzle.playingfield;

public interface Action {

    void execute();
}
