package de.mwvb.blockpuzzle.playingfield

/** Spielfeld-Koordinate */
data class QPosition(val x: Int, val y: Int)