package de.mwvb.blockpuzzle.gamestate;

public enum GamePlayState {

    PLAYING,
    /** z.B. wenn Spielfeld voll */
    LOST_GAME,
    WON_GAME
}
