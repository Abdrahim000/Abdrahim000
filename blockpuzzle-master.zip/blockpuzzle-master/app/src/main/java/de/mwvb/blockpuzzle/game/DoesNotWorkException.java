package de.mwvb.blockpuzzle.game;

public class DoesNotWorkException extends RuntimeException {

    public DoesNotWorkException() {
    }
}
