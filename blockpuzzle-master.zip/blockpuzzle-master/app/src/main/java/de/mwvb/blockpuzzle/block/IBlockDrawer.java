package de.mwvb.blockpuzzle.block;

public interface IBlockDrawer {

    void draw(float x, float y, BlockDrawParameters p);
}
