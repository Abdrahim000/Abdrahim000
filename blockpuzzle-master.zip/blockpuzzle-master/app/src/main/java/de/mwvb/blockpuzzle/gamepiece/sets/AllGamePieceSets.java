package de.mwvb.blockpuzzle.gamepiece.sets;

import de.mwvb.blockpuzzle.gamepiece.IGamePieceSet;

/** GENERATED */
public class AllGamePieceSets {

    public static final IGamePieceSet[] sets = new IGamePieceSet[] {
		new GamePieceSet0001(),
		new GamePieceSet0002(),
		new GamePieceSet0003(),
		new GamePieceSet0004(),
		new GamePieceSet0005(),
		new GamePieceSet0006(),
		new GamePieceSet0007(),
		new GamePieceSet0008(),
		new GamePieceSet0009(),
		new GamePieceSet0010(),
		new GamePieceSet0011(),
		new GamePieceSet0012(),
		new GamePieceSet0013(),
		new GamePieceSet0014(),
		new GamePieceSet0015(),
		new GamePieceSet0016(),
		new GamePieceSet0017(),
		new GamePieceSet0018(),
		new GamePieceSet0019(),
		new GamePieceSet0020(),
		new GamePieceSet0021(),
		new GamePieceSet0022(),
		new GamePieceSet0023(),
		new GamePieceSet0024(),
		new GamePieceSet0025(),
		new GamePieceSet0026(),
		new GamePieceSet0027(),
		new GamePieceSet0028(),
		new GamePieceSet0029(),
		new GamePieceSet0030(),
		new GamePieceSet0031(),
		new GamePieceSet0032(),
		new GamePieceSet0033(),
		new GamePieceSet0034(),
		new GamePieceSet0035(),
		new GamePieceSet0036(),
		new GamePieceSet0037(),
		new GamePieceSet0038(),
		new GamePieceSet0039(),
		new GamePieceSet0040(),
		new GamePieceSet0041() // Development only
	};

}
