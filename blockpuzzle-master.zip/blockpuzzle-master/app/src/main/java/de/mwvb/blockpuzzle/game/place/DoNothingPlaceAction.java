package de.mwvb.blockpuzzle.game.place;

public final class DoNothingPlaceAction implements IPlaceAction {

    @Override
    public void perform(PlaceActionModel info) {
        // do nothing
    }
}
