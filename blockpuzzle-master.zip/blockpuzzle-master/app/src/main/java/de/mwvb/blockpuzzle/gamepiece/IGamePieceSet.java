package de.mwvb.blockpuzzle.gamepiece;

public interface IGamePieceSet {

    String[] getGamePieceSet();
}
