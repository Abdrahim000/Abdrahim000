package de.mwvb.blockpuzzle.global.messages;

public final class TestMessageFactory extends MessageFactory {

    public TestMessageFactory() {
        super(null);
    }

    @Override
    public void show(int id) { // do nothing
    }
}
