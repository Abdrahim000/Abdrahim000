# List of the sources of the sound files

## used
- crunch.wav = unknown
- explosion.wav = https://freesound.org/people/V-ktor/sounds/482993/
- jeqa.wav (Japan Earthquake alert) = https://freesound.org/people/gorkem.yilmaz/sounds/518087/
- laughter.wav = https://freesound.org/people/martysonic/sounds/383326/
- money.wav = https://freesound.org/people/rolandseer/sounds/443334/
- applause.mp3 = https://freesound.org/people/milton./sounds/77101/
- ( brickdrop2.wav = https://freesound.org/people/Robinhood76/sounds/503554/ )
- alarm = https://freesound.org/people/Tomlija/sounds/96831/ 
- emptysb "empty screen bonus" (IT) = https://voicegenerator.io

## voicegenerator.io
- more40: "More than 40 percent", Google UK English Male, Pitch 1.4, Speed 1.2 

## candidates
- emergency alert = https://freesound.org/people/NocturnalNarrations/sounds/415266/
- nuclear alarm = https://freesound.org/people/radio_illuminati/sounds/206141/
- success fanfare = https://freesound.org/people/FunWithSound/sounds/456966/

## not used
- spaceshipalarm.wav = https://freesound.org/people/Tim_Verberne/sounds/514080/
