Anbieter: Github user SoltauFintel. Kontakt bspw. über Issues möglich.

gesammelte Daten: keine

Die App speichert den Spielstand auf dem Endgerät, damit dieser beim Beenden der App nicht verloren geht. Außerdem wird der frei zu wählende Spielername abgefragt und auf dem Endgerät gespeichert.

benötigte App Rechte: keine

Erstellung: 06.12.2020

Webseiten: https://github.com/SoltauFintel/blockpuzzle | https://github.com/SoltauFintel
